var $export = require('./_export');
var define = require('./_object-define');

$export($export.S + $export.F, 'Object', { define: define });
