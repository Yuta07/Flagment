module.exports = require('./_global');
