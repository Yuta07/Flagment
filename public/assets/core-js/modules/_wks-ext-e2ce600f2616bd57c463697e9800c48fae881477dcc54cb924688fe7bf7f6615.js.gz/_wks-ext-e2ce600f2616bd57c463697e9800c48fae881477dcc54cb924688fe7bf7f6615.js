exports.f = require('./_wks');
