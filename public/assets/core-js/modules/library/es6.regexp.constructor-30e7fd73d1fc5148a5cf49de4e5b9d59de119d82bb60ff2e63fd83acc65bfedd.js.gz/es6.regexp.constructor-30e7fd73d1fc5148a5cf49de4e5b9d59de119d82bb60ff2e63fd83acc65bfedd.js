require('./_set-species')('RegExp');
