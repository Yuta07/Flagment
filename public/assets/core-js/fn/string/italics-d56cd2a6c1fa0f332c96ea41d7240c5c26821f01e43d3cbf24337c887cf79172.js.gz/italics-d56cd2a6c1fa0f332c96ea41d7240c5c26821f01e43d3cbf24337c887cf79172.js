require('../../modules/es6.string.italics');
module.exports = require('../../modules/_core').String.italics;
