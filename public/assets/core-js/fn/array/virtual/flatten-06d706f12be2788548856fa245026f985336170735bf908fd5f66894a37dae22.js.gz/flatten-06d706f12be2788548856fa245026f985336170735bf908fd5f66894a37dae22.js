require('../../../modules/es7.array.flatten');
module.exports = require('../../../modules/_entry-virtual')('Array').flatten;
