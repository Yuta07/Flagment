require('../../modules/es6.math.asinh');
module.exports = require('../../modules/_core').Math.asinh;
