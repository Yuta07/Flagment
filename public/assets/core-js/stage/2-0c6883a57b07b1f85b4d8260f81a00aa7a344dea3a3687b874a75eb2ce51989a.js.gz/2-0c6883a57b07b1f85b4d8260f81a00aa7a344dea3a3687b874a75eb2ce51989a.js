require('../modules/es7.symbol.async-iterator');
require('../modules/es7.string.trim-left');
require('../modules/es7.string.trim-right');
module.exports = require('./3');
