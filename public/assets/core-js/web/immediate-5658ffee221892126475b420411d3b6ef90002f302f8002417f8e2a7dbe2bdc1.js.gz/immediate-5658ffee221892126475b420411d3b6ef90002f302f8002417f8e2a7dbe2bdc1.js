require('../modules/web.immediate');
module.exports = require('../modules/_core');
