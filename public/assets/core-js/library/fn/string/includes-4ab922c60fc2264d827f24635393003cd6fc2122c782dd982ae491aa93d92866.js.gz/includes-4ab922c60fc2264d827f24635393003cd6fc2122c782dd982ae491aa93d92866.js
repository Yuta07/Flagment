require('../../modules/es6.string.includes');
module.exports = require('../../modules/_core').String.includes;
