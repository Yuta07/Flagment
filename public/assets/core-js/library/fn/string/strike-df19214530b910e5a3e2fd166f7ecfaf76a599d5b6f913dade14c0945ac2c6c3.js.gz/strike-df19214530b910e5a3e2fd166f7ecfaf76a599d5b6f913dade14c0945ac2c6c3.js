require('../../modules/es6.string.strike');
module.exports = require('../../modules/_core').String.strike;
