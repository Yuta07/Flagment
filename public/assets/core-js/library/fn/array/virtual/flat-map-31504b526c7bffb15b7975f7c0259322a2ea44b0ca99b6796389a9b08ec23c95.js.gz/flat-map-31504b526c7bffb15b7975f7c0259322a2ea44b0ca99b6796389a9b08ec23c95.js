require('../../../modules/es7.array.flat-map');
module.exports = require('../../../modules/_entry-virtual')('Array').flatMap;
