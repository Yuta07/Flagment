require('../../modules/es6.math.fround');
module.exports = require('../../modules/_core').Math.fround;
