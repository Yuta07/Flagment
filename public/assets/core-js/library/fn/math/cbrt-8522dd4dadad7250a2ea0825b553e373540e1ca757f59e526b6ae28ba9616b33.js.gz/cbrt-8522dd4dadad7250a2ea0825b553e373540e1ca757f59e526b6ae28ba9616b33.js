require('../../modules/es6.math.cbrt');
module.exports = require('../../modules/_core').Math.cbrt;
