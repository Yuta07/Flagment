"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = _findGetResult;
function _findGetResult(v, x) {
    return x;
}
module.exports = exports["default"];
