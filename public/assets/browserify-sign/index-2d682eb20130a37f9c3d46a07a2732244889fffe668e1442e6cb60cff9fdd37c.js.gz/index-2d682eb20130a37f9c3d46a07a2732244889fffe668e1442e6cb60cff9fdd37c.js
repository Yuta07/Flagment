var crypto = require('crypto')

exports.createSign = crypto.createSign
exports.Sign = crypto.Sign

exports.createVerify = crypto.createVerify
exports.Verify = crypto.Verify
;
