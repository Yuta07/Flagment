#!/usr/bin/env node
/*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/

(function () {
  "use strict";

  var atob = require('../index')
    ;

  console.log(atob(process.argv[2]));
}());
