'use strict';

module.exports = require('es5-ext/object/primitive-set')('key',
	'value', 'key+value');
