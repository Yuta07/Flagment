module.exports = {
  test: /\.(ts|tsx)?(\.erb)?$/,
  loader: 'ts-loader'
}
;
