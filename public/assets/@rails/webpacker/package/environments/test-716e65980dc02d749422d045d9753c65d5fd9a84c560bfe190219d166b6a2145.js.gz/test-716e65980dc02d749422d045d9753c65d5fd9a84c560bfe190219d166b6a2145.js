const Environment = require('../environment')

module.exports = class extends Environment {}
;
