// TODO: test isCollection.js

;
