'use strict';

// Reserved keywords not allowed to use in the parser
module.exports = {
  end: true
};
