module.exports = [
  require('./compile'),
  require('./eval'),
  require('./help'),
  require('./parse'),
  require('./parser')
];
