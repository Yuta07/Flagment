module.exports = [
  require('./bellNumbers'),
  require('./composition'),
  require('./stirlingS2'),
  require('./catalan')
];
