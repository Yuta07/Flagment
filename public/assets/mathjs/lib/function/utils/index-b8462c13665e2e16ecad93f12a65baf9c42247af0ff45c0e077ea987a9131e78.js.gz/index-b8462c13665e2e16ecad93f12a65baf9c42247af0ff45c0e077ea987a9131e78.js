module.exports = [
  require('./clone'),
  require('./isInteger'),
  require('./isNegative'),
  require('./isNumeric'),
  require('./isPositive'),
  require('./isPrime'),
  require('./isZero'),
  require('./isNaN'),
  require('./typeof')
];
