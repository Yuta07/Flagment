module.exports = [
  require('./bitAnd'),
  require('./bitNot'),
  require('./bitOr'),
  require('./bitXor'),
  require('./leftShift'),
  require('./rightArithShift'),
  require('./rightLogShift')
];
