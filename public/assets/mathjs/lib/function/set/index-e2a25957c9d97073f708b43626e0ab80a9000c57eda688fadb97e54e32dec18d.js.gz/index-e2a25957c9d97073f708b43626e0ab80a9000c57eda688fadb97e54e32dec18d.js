module.exports = [
  require('./setCartesian'),
  require('./setDifference'),
  require('./setDistinct'),
  require('./setIntersect'),
  require('./setIsSubset'),
  require('./setMultiplicity'),
  require('./setPowerset'),
  require('./setSize'),
  require('./setSymDifference'),
  require('./setUnion')
];
