module.exports = [
  require('./and'),
  require('./not'),
  require('./or'),
  require('./xor')
];
