module.exports = [
  require('./arg'),
  require('./conj'),
  require('./im'),
  require('./re')
];
