'use strict';

exports.array = require('./array');
exports['boolean'] = require('./boolean');
exports['function'] = require('./function');
exports.number = require('./number');
exports.object = require('./object');
exports.string = require('./string');
exports.types = require('./types');
exports.emitter = require('./emitter');
