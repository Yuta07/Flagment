module.exports = [
  // type
  require('./ResultSet')
];
