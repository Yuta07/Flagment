module.exports = [
  // type
  require('./BigNumber'),

  // construction function
  require('./function/bignumber')
];
