module.exports = [
  // type
  require('./Fraction'),

  // construction function
  require('./function/fraction')
];
