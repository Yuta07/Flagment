module.exports = [
  // type
  require('./Chain'),

  // construction function
  require('./function/chain')
];
