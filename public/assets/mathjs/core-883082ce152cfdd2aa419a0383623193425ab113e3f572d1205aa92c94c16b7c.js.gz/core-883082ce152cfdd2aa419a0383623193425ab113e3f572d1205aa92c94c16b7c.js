module.exports = require('./lib/core/core');
