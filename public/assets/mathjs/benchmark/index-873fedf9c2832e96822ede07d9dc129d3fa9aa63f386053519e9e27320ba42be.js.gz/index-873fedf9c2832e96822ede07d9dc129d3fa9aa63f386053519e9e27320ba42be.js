// run all benchmarks
require ('./expression_parser');
require ('./algebra');
require ('./matrix_operations');
