'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var browsers = exports.browsers = require('../../data/browsers');
