exports.isatty = function () {};
exports.setRawMode = function () {};
