(function() {
  exports.Cmd = require('./cmd').Cmd;

  exports.Opt = require('./cmd').Opt;

  exports.Arg = require('./cmd').Arg;

  exports.shell = require('./shell');

  exports.require = require;

}).call(this);
