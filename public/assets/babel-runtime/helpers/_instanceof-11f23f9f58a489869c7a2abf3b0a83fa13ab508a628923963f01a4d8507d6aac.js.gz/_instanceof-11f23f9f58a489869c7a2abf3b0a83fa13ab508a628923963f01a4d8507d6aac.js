module.exports = require("./instanceof.js");
