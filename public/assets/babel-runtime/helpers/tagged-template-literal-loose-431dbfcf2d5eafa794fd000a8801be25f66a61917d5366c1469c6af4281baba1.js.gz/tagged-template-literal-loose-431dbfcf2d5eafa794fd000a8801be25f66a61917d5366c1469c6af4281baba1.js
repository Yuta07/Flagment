module.exports = require("./taggedTemplateLiteralLoose.js");
