module.exports = require("./interopRequireDefault.js");
