module.exports = require("./newArrowCheck.js");
