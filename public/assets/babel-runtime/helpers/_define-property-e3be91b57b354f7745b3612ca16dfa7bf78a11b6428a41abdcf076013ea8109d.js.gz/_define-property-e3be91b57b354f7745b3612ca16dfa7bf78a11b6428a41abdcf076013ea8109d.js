module.exports = require("./defineProperty.js");
