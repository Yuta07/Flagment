module.exports = require("./typeof.js");
