module.exports = require("./inherits.js");
