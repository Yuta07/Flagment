module.exports = require("./slicedToArray.js");
