module.exports = require("./defineEnumerableProperties.js");
