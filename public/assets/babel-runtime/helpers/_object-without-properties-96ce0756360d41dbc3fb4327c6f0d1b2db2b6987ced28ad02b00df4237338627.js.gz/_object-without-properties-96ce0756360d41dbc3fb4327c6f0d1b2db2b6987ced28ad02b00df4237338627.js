module.exports = require("./objectWithoutProperties.js");
