module.exports = require("./objectDestructuringEmpty.js");
