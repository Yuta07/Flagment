module.exports = require("./classCallCheck.js");
