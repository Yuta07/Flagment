module.exports = require("./selfGlobal.js");
