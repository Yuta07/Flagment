module.exports = { "default": require("core-js/library/fn/json/stringify"), __esModule: true };
