module.exports = { "default": require("core-js/library/fn/symbol/observable"), __esModule: true };
