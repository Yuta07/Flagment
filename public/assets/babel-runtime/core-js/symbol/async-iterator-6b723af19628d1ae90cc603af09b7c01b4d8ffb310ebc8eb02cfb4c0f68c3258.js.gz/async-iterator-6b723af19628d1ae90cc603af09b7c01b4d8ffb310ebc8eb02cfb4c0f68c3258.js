module.exports = { "default": require("core-js/library/fn/symbol/async-iterator"), __esModule: true };
