module.exports = { "default": require("core-js/library/fn/symbol/match"), __esModule: true };
