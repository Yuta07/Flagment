module.exports = { "default": require("core-js/library/fn/observable"), __esModule: true };
