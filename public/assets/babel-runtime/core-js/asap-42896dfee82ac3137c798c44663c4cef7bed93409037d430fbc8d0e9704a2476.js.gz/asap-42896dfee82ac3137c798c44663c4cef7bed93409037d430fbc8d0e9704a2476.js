module.exports = { "default": require("core-js/library/fn/asap"), __esModule: true };
