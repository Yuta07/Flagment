module.exports = { "default": require("core-js/library/fn/string/trim-start"), __esModule: true };
