module.exports = { "default": require("core-js/library/fn/string/match-all"), __esModule: true };
