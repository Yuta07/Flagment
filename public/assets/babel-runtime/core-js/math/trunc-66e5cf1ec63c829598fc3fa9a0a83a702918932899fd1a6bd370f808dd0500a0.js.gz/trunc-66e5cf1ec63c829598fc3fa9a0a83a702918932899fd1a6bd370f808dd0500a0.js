module.exports = { "default": require("core-js/library/fn/math/trunc"), __esModule: true };
