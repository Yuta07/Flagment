module.exports = { "default": require("core-js/library/fn/math/iaddh"), __esModule: true };
