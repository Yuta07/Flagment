module.exports = { "default": require("core-js/library/fn/math/acosh"), __esModule: true };
