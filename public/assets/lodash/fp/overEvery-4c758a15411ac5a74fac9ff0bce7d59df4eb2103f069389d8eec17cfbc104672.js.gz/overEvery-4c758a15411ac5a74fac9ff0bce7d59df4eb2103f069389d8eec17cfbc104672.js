var convert = require('./convert'),
    func = convert('overEvery', require('../overEvery'));

func.placeholder = require('./placeholder');
module.exports = func;
