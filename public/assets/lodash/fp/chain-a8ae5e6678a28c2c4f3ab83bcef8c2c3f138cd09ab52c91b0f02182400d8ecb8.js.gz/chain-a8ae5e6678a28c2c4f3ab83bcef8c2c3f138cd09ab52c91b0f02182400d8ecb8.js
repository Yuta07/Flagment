var convert = require('./convert'),
    func = convert('chain', require('../chain'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
