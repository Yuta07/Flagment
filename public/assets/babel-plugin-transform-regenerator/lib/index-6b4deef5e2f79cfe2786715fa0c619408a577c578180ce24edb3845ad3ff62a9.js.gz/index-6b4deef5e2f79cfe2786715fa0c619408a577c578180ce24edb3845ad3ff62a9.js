"use strict";

module.exports = require("regenerator-transform");
