"use strict";

exports.__esModule = true;
var defaultWebIncludes = exports.defaultWebIncludes = ["web.timers", "web.immediate", "web.dom.iterable"];
