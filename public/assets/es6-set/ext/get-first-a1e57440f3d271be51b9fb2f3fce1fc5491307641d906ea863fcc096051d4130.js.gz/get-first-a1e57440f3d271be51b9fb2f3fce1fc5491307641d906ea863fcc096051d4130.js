'use strict';

module.exports = function () {
	return this.values().next().value;
};
