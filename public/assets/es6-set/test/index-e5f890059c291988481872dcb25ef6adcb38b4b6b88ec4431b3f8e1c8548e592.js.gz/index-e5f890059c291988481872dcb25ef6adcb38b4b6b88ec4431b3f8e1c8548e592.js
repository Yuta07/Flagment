'use strict';

module.exports = function (T, a) { a((new T(['raz', 'dwa'])).size, 2); };
