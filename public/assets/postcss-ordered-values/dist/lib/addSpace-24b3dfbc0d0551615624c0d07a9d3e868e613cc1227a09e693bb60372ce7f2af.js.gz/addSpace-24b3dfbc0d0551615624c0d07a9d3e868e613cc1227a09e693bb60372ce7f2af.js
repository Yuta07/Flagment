'use strict';

exports.__esModule = true;
exports.default = addSpace;
function addSpace() {
    return { type: 'space', value: ' ' };
}
module.exports = exports['default'];
