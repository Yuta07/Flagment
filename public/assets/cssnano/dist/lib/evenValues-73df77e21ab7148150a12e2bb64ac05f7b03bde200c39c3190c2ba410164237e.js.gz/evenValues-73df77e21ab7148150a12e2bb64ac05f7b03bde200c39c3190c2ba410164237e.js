"use strict";

exports.__esModule = true;
exports.default = getEvenValues;
function getEvenValues(list, index) {
    return index % 2 === 0;
}
module.exports = exports["default"];
