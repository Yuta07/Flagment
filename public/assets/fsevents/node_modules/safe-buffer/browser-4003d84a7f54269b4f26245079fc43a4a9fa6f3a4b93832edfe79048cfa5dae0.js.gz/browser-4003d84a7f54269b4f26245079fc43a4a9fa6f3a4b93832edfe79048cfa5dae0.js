module.exports = require('buffer')
;
