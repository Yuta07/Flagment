"use strict";

var isImplemented = require("../../../math/asinh/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
