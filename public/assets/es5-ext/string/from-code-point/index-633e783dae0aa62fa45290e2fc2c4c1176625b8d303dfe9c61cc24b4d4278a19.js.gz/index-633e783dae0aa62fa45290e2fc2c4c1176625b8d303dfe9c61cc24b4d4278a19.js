"use strict";

module.exports = require("./is-implemented")()
	? String.fromCodePoint
	: require("./shim");
